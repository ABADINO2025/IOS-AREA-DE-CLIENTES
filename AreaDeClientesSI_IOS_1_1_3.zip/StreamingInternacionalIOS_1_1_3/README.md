# Area de Clientes SI! iOS App

Proyecto iOS en SwiftUI + WKWebView preparado para abrir únicamente el panel oficial de Streaming Internacional, arrancando directamente en la ruta de administración WordPress.

## Configuración final aplicada

- Nombre visible de la app: `Area de Clientes SI!`
- Bundle Identifier: `com.streaminginternacional.areadeclientessi`
- URL principal: `https://streaminginternacional.com/administracion/`
- Marca visual: azul profundo + azul eléctrico + cian, alineada al logo suministrado

## Qué hace esta versión

- Muestra una pantalla inicial animada con el logo.
- Abre directamente `https://streaminginternacional.com/administracion/`.
- Permite navegar solo dentro del dominio autorizado y sus subdominios.
- Cuando el sitio intenta abrir enlaces externos, redes, WhatsApp, mail, teléfono u otros esquemas, los deriva al navegador o a la app nativa del dispositivo.
- Refuerza la compatibilidad con WordPress mediante cookies persistentes, JavaScript habilitado, soporte para `target="_blank"`, ventanas emergentes controladas, reproducción inline de medios y permisos listos para cámara, micrófono y fototeca.
- Los recursos descargables comunes como PDF, ZIP, documentos y archivos multimedia se abren fuera de la app para aprovechar mejor las apps nativas del sistema.
- Incluye iconos de app generados a partir del logo suministrado.

## Archivo de configuración

El archivo `AllowedSites.plist` quedó preparado con un único sitio:

- `https://streaminginternacional.com/administracion/`
- hosts permitidos:
  - `streaminginternacional.com`
  - `www.streaminginternacional.com`

Si quieres cambiar el dominio principal, edita ese archivo y deja un solo registro.

## Estructura principal

- `ContentView.swift`: splash animado y arranque directo del navegador.
- `BrandTheme.swift`: colores visuales de la app.
- `BrowserViewModel.swift`: reglas de navegación, compatibilidad WordPress y apertura externa.
- `AllowedSites.plist`: sitio principal permitido.
- `Assets.xcassets/BrandLogo.imageset`: logo para splash.
- `Assets.xcassets/AppIcon.appiconset`: iconos de la app.

## Abrir en Xcode

1. Descomprime el ZIP.
2. Abre `SitiosNavigator.xcodeproj` en Xcode.
3. Configura tu Team de firma.
4. Ejecuta en simulador o iPhone.

## Nota técnica

La pantalla de arranque animada está resuelta dentro de SwiftUI. En iOS, la launch screen nativa previa al arranque no admite animaciones reales; por eso se usa un splash visual inmediatamente al iniciar la app.

Aunque la base quedó reforzada para WordPress, siempre conviene probar el flujo exacto de tu sitio en un iPhone real, sobre todo si usas plugins que dependan de popups complejos, capturas multimedia avanzadas o pasarelas externas.
