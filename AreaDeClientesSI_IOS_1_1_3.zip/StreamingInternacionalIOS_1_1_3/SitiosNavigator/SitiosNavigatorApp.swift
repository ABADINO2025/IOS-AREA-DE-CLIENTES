import SwiftUI

@main
struct SitiosNavigatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .tint(BrandTheme.cyan)
        }
    }
}
