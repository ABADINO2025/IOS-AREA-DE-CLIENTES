import Foundation
import WebKit
import Combine

final class BrowserViewModel: NSObject, ObservableObject {
    @Published var titleText: String = ""
    @Published var progress: Double = 0
    @Published var canGoBack: Bool = false
    @Published var canGoForward: Bool = false
    @Published var isLoading: Bool = false
    @Published var lastErrorMessage: String?

    let site: Website
    let webView: WKWebView

    private let allowedHosts: Set<String>
    private var observations: [NSKeyValueObservation] = []

    private static let sharedProcessPool = WKProcessPool()
    private let downloadableExtensions: Set<String> = [
        "pdf", "zip", "rar", "7z", "doc", "docx", "xls", "xlsx", "ppt", "pptx",
        "csv", "mp3", "mp4", "mov", "avi", "jpg", "jpeg", "png", "webp"
    ]

    var openExternalURL: ((URL) -> Void)?

    init(site: Website, allAllowedHosts: Set<String>) {
        self.site = site
        self.allowedHosts = Set(allAllowedHosts.map { $0.lowercased() })

        let configuration = WKWebViewConfiguration()
        configuration.processPool = Self.sharedProcessPool
        configuration.websiteDataStore = .default()
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.defaultWebpagePreferences.preferredContentMode = .mobile

        self.webView = WKWebView(frame: .zero, configuration: configuration)

        super.init()

        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.allowsLinkPreview = true
        webView.isOpaque = false
        webView.backgroundColor = .clear
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.keyboardDismissMode = .interactive

        configureObservers()
        goHome()
    }

    deinit {
        observations.forEach { $0.invalidate() }
    }

    func goHome() {
        load(site.url)
    }

    func load(_ url: URL) {
        var request = URLRequest(url: url)
        request.cachePolicy = .useProtocolCachePolicy
        request.timeoutInterval = 60
        webView.load(request)
    }

    func reload() {
        webView.reload()
    }

    func goBack() {
        guard webView.canGoBack else { return }
        webView.goBack()
    }

    func goForward() {
        guard webView.canGoForward else { return }
        webView.goForward()
    }

    func openCurrentPageExternally() {
        let currentURL = webView.url ?? site.url
        openExternalURL?(currentURL)
    }

    private func configureObservers() {
        observations = [
            webView.observe(\.title, options: [.initial, .new]) { [weak self] webView, _ in
                DispatchQueue.main.async {
                    self?.titleText = webView.title ?? self?.site.name ?? ""
                }
            },
            webView.observe(\.estimatedProgress, options: [.initial, .new]) { [weak self] webView, _ in
                DispatchQueue.main.async {
                    self?.progress = webView.estimatedProgress
                }
            },
            webView.observe(\.canGoBack, options: [.initial, .new]) { [weak self] webView, _ in
                DispatchQueue.main.async {
                    self?.canGoBack = webView.canGoBack
                }
            },
            webView.observe(\.canGoForward, options: [.initial, .new]) { [weak self] webView, _ in
                DispatchQueue.main.async {
                    self?.canGoForward = webView.canGoForward
                }
            },
            webView.observe(\.isLoading, options: [.initial, .new]) { [weak self] webView, _ in
                DispatchQueue.main.async {
                    self?.isLoading = webView.isLoading
                }
            }
        ]
    }

    private func isAllowed(url: URL) -> Bool {
        guard let host = url.host?.lowercased(), !host.isEmpty else { return true }

        return allowedHosts.contains { allowed in
            host == allowed || host.hasSuffix("." + allowed)
        }
    }

    private func schemeType(for url: URL) -> SchemeType {
        let scheme = url.scheme?.lowercased() ?? ""

        switch scheme {
        case "http", "https":
            return .web
        case "about", "blob", "data", "javascript":
            return .internalOnly
        default:
            return .externalApp
        }
    }

    private func isDownloadableResource(_ url: URL) -> Bool {
        let ext = url.pathExtension.lowercased()
        return downloadableExtensions.contains(ext)
    }

    private func shouldOpenExternally(_ url: URL) -> Bool {
        switch schemeType(for: url) {
        case .internalOnly:
            return false
        case .externalApp:
            return true
        case .web:
            if isDownloadableResource(url) {
                return true
            }
            return !isAllowed(url: url)
        }
    }

    private enum SchemeType {
        case web
        case internalOnly
        case externalApp
    }
}

extension BrowserViewModel: WKNavigationDelegate, WKUIDelegate {
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        DispatchQueue.main.async { [weak self] in
            self?.lastErrorMessage = nil
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        DispatchQueue.main.async { [weak self] in
            self?.titleText = webView.title ?? self?.site.name ?? ""
            self?.lastErrorMessage = nil
        }
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.reload()
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        DispatchQueue.main.async { [weak self] in
            self?.lastErrorMessage = error.localizedDescription
        }
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        let nsError = error as NSError
        if nsError.domain == NSURLErrorDomain, nsError.code == NSURLErrorCancelled {
            return
        }

        DispatchQueue.main.async { [weak self] in
            self?.lastErrorMessage = error.localizedDescription
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }

        if navigationAction.targetFrame == nil {
            if shouldOpenExternally(url) {
                openExternalURL?(url)
            } else {
                load(url)
            }
            decisionHandler(.cancel)
            return
        }

        guard shouldOpenExternally(url) else {
            decisionHandler(.allow)
            return
        }

        if site.opensExternallyWhenBlocked {
            openExternalURL?(url)
        }
        decisionHandler(.cancel)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        guard let url = navigationResponse.response.url else {
            decisionHandler(.allow)
            return
        }

        if shouldOpenExternally(url) {
            if site.opensExternallyWhenBlocked {
                openExternalURL?(url)
            }
            decisionHandler(.cancel)
            return
        }

        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        guard let url = navigationAction.request.url else { return nil }

        if shouldOpenExternally(url) {
            if site.opensExternallyWhenBlocked {
                openExternalURL?(url)
            }
        } else {
            load(url)
        }

        return nil
    }

    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin, initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType, decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        decisionHandler(.grant)
    }

    func webView(_ webView: WKWebView, authenticationChallenge challenge: URLAuthenticationChallenge, shouldAllowDeprecatedTLS decisionHandler: @escaping (Bool) -> Void) {
        decisionHandler(false)
    }
}
