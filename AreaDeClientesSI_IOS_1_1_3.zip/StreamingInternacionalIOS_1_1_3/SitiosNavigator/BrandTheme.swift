import SwiftUI

enum BrandTheme {
    static let deepBlue = Color(red: 0.02, green: 0.09, blue: 0.20)
    static let royalBlue = Color(red: 0.03, green: 0.18, blue: 0.35)
    static let electricBlue = Color(red: 0.00, green: 0.39, blue: 0.60)
    static let cyan = Color(red: 0.28, green: 0.86, blue: 0.95)
    static let softText = Color.white.opacity(0.82)

    static let splashGradient = LinearGradient(
        colors: [deepBlue, royalBlue, electricBlue],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
}
