import Foundation

struct Website: Codable, Identifiable, Hashable {
    let id: UUID
    let name: String
    let subtitle: String
    let url: URL
    let symbolName: String
    let category: String
    let allowedHosts: [String]
    let opensExternallyWhenBlocked: Bool

    init(
        id: UUID = UUID(),
        name: String,
        subtitle: String,
        url: URL,
        symbolName: String,
        category: String,
        allowedHosts: [String],
        opensExternallyWhenBlocked: Bool = true
    ) {
        self.id = id
        self.name = name
        self.subtitle = subtitle
        self.url = url
        self.symbolName = symbolName
        self.category = category
        self.allowedHosts = allowedHosts
        self.opensExternallyWhenBlocked = opensExternallyWhenBlocked
    }
}
