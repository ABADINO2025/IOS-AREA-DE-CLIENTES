import SwiftUI

struct BrowserScreen: View {
    @Environment(\.openURL) private var openURL
    @StateObject private var viewModel: BrowserViewModel

    init(site: Website, allowedHosts: Set<String>) {
        _viewModel = StateObject(wrappedValue: BrowserViewModel(site: site, allAllowedHosts: allowedHosts))
    }

    var body: some View {
        VStack(spacing: 0) {
            if viewModel.isLoading {
                ProgressView(value: viewModel.progress)
                    .progressViewStyle(.linear)
                    .tint(BrandTheme.cyan)
            }

            WebViewContainer(viewModel: viewModel)
                .ignoresSafeArea(edges: .bottom)
        }
        .background(BrandTheme.deepBlue.opacity(0.06).ignoresSafeArea())
        .navigationTitle(viewModel.titleText.isEmpty ? viewModel.site.name : viewModel.titleText)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .bottomBar) {
                Button {
                    viewModel.goBack()
                } label: {
                    Image(systemName: "chevron.backward")
                }
                .disabled(!viewModel.canGoBack)

                Button {
                    viewModel.goForward()
                } label: {
                    Image(systemName: "chevron.forward")
                }
                .disabled(!viewModel.canGoForward)

                Spacer()

                Button {
                    viewModel.goHome()
                } label: {
                    Image(systemName: "house")
                }

                Button {
                    viewModel.reload()
                } label: {
                    Image(systemName: "arrow.clockwise")
                }

                Button {
                    viewModel.openCurrentPageExternally()
                } label: {
                    Image(systemName: "safari")
                }
            }
        }
        .alert("No se pudo cargar la página", isPresented: errorBinding) {
            Button("Cerrar", role: .cancel) {
                viewModel.lastErrorMessage = nil
            }
        } message: {
            Text(viewModel.lastErrorMessage ?? "Error desconocido.")
        }
        .onAppear {
            viewModel.openExternalURL = { url in
                openURL(url)
            }
        }
    }

    private var errorBinding: Binding<Bool> {
        Binding(
            get: { viewModel.lastErrorMessage != nil },
            set: { newValue in
                if !newValue {
                    viewModel.lastErrorMessage = nil
                }
            }
        )
    }
}
