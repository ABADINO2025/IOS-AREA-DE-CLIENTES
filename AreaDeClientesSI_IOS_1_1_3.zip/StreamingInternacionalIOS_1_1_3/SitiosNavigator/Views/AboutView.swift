import SwiftUI

struct AboutView: View {
    var body: some View {
        NavigationStack {
            List {
                Section("Qué incluye esta app") {
                    Label("Lista de webs configurables", systemImage: "checkmark.circle")
                    Label("Navegación embebida con WKWebView", systemImage: "checkmark.circle")
                    Label("Control de dominios permitidos", systemImage: "checkmark.circle")
                    Label("Botones de volver, avanzar, recargar, inicio y Safari", systemImage: "checkmark.circle")
                }

                Section("Cómo cargar tus sitios") {
                    Text("Abre AllowedSites.plist dentro del proyecto y reemplaza los ejemplos por tus URLs, nombres, iconos y dominios permitidos.")
                }

                Section("Recomendación") {
                    Text("Usa URLs HTTPS. Si necesitas cargar un sitio HTTP, deberás añadir una excepción de App Transport Security en Info.plist.")
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Información")
        }
    }
}

#Preview {
    AboutView()
}
