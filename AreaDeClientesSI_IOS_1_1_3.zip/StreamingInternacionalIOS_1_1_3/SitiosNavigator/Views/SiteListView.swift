import SwiftUI

struct SiteListView: View {
    @State private var searchText = ""
    private let sites = SiteRepository.loadSites()

    private var filteredSites: [Website] {
        guard !searchText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return sites
        }

        return sites.filter { site in
            site.name.localizedCaseInsensitiveContains(searchText) ||
            site.subtitle.localizedCaseInsensitiveContains(searchText) ||
            site.category.localizedCaseInsensitiveContains(searchText)
        }
    }

    private var groupedSites: [(key: String, value: [Website])] {
        Dictionary(grouping: filteredSites, by: \.category)
            .sorted { $0.key.localizedCaseInsensitiveCompare($1.key) == .orderedAscending }
    }

    private var allowedHosts: Set<String> {
        SiteRepository.allAllowedHosts(from: sites)
    }

    var body: some View {
        NavigationStack {
            Group {
                if filteredSites.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 42))
                            .foregroundStyle(.secondary)

                        Text("No hay coincidencias")
                            .font(.headline)

                        Text("Edita tu búsqueda o agrega sitios en AllowedSites.plist.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 24)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(.systemGroupedBackground))
                } else {
                    List {
                        ForEach(groupedSites, id: \.key) { group in
                            Section(group.key) {
                                ForEach(group.value) { site in
                                    NavigationLink(value: site) {
                                        SiteRow(site: site)
                                    }
                                }
                            }
                        }
                    }
                    .listStyle(.insetGrouped)
                }
            }
            .navigationTitle("Sitios permitidos")
            .searchable(text: $searchText, prompt: "Buscar sitio")
            .navigationDestination(for: Website.self) { site in
                BrowserScreen(site: site, allowedHosts: allowedHosts)
            }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    EditSitesHintButton()
                }
            }
        }
    }
}

private struct SiteRow: View {
    let site: Website

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: site.symbolName)
                .font(.system(size: 20, weight: .semibold))
                .frame(width: 42, height: 42)
                .background(.blue.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))

            VStack(alignment: .leading, spacing: 4) {
                Text(site.name)
                    .font(.headline)

                Text(site.subtitle)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
        }
        .padding(.vertical, 4)
    }
}

private struct EditSitesHintButton: View {
    var body: some View {
        Menu {
            Text("Edita el archivo AllowedSites.plist para cargar tus webs específicas.")
        } label: {
            Image(systemName: "slider.horizontal.3")
        }
    }
}

#Preview {
    SiteListView()
}
