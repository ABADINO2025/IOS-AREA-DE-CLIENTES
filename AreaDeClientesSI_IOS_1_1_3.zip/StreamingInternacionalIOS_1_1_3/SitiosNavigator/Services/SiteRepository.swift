import Foundation

enum SiteRepository {
    static func loadSites() -> [Website] {
        guard let url = Bundle.main.url(forResource: "AllowedSites", withExtension: "plist") else {
            return fallbackSites()
        }

        do {
            let data = try Data(contentsOf: url)
            let decoder = PropertyListDecoder()
            return try decoder.decode([Website].self, from: data)
        } catch {
            print("No se pudo cargar AllowedSites.plist: \(error)")
            return fallbackSites()
        }
    }

    static func allAllowedHosts(from sites: [Website]) -> Set<String> {
        Set(
            sites.flatMap { site in
                let hostFromURL = site.url.host.map { [$0] } ?? []
                return hostFromURL + site.allowedHosts
            }
        )
    }

    private static func fallbackSites() -> [Website] {
        [
            Website(
                name: "Streaming Internacional",
                subtitle: "Administración WordPress",
                url: URL(string: "https://streaminginternacional.com/administracion/")!,
                symbolName: "play.tv.fill",
                category: "Principal",
                allowedHosts: ["streaminginternacional.com", "www.streaminginternacional.com"]
            )
        ]
    }
}
