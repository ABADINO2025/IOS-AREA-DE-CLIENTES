import SwiftUI

struct ContentView: View {
    private let sites = SiteRepository.loadSites()

    @State private var showSplash = true
    @State private var hasStartedAnimation = false
    @State private var logoOpacity = 0.0
    @State private var logoScale = 0.82
    @State private var glowScale = 0.75
    @State private var textOpacity = 0.0

    private var primarySite: Website? {
        sites.first
    }

    private var allowedHosts: Set<String> {
        SiteRepository.allAllowedHosts(from: sites)
    }

    var body: some View {
        ZStack {
            if let site = primarySite {
                NavigationStack {
                    BrowserScreen(site: site, allowedHosts: allowedHosts)
                }
                .opacity(showSplash ? 0.01 : 1)
                .allowsHitTesting(!showSplash)
            } else {
                ConfigurationErrorView()
            }

            if showSplash {
                SplashOverlayView(
                    logoOpacity: logoOpacity,
                    logoScale: logoScale,
                    glowScale: glowScale,
                    textOpacity: textOpacity
                )
                .transition(.opacity)
            }
        }
        .onAppear {
            startSplashAnimationIfNeeded()
        }
    }

    private func startSplashAnimationIfNeeded() {
        guard !hasStartedAnimation else { return }
        hasStartedAnimation = true

        withAnimation(.easeOut(duration: 0.85)) {
            logoOpacity = 1
            logoScale = 1
            glowScale = 1.08
        }

        withAnimation(.easeOut(duration: 0.65).delay(0.25)) {
            textOpacity = 1
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.9) {
            withAnimation(.easeInOut(duration: 0.45)) {
                showSplash = false
            }
        }
    }
}

private struct SplashOverlayView: View {
    let logoOpacity: Double
    let logoScale: Double
    let glowScale: Double
    let textOpacity: Double

    var body: some View {
        ZStack {
            BrandTheme.splashGradient
                .ignoresSafeArea()

            Circle()
                .fill(BrandTheme.cyan.opacity(0.28))
                .frame(width: 240, height: 240)
                .blur(radius: 30)
                .scaleEffect(glowScale)

            VStack(spacing: 18) {
                Image("BrandLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 230, height: 230)
                    .scaleEffect(logoScale)
                    .opacity(logoOpacity)
                    .shadow(color: BrandTheme.cyan.opacity(0.35), radius: 28, x: 0, y: 12)

                VStack(spacing: 6) {
                    Text("Streaming Internacional")
                        .font(.system(size: 28, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)

                    Text("Panel de Administración")
                        .font(.system(size: 15, weight: .medium, design: .rounded))
                        .foregroundStyle(BrandTheme.softText)
                }
                .opacity(textOpacity)
            }
            .padding(.horizontal, 24)
        }
    }
}

private struct ConfigurationErrorView: View {
    var body: some View {
        ZStack {
            Color(.systemBackground)
                .ignoresSafeArea()

            VStack(spacing: 14) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.system(size: 46))
                    .foregroundStyle(.orange)

                Text("No hay un sitio configurado")
                    .font(.title3.weight(.semibold))

                Text("Revisa AllowedSites.plist y deja una única URL principal para la app.")
                    .font(.body)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 28)
            }
        }
    }
}

#Preview {
    ContentView()
}
